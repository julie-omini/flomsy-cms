<?php
class Plugins {
    private $Class;
    private $CMS;
    function __construct($CMS) {
        $this->CMS = $CMS;
        $name = "ennNode";
        if (file_exists("./usr/plugins/". $name."/Main.php")){
            $CMS->Security->Include("./usr/plugins/". $name."/Main.php");
            $this->Class[$name] = new $name();
        } else {
            echo "Impossible de charger le plugin : ".$name;
        }
    }
    public function __get($name) {
        return isset($this->Class[$name])?$this->Class[$name]:NULL;
    }
}